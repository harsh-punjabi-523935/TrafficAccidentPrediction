import pandas as pd
import os
from datetime import datetime

# Paths
RAW_DIR = "../data/raw"
PROCESSED_DIR = "../data/processed"
os.makedirs(PROCESSED_DIR, exist_ok=True)

# Automatically pick the latest file
def get_latest_raw_file():
    files = [f for f in os.listdir(RAW_DIR) if f.endswith(".csv")]
    files.sort(reverse=True)
    return os.path.join(RAW_DIR, files[0])

# Preprocessing function
def preprocess_data(filepath):
    print(f"📂 Reading data from {filepath}")
    df = pd.read_csv(filepath, sep=",", encoding='utf-8', on_bad_lines='skip')

    # Extract LATITUDE and LONGITUDE from geometry
import ast

def extract_lat_lon(geometry):
    try:
        geo = ast.literal_eval(geometry)
        coords = geo["coordinates"][0][0]
        lon, lat = coords[0], coords[1]
        return pd.Series([lat, lon])
    except:
        return pd.Series([None, None])

    df[['LATITUDE', 'LONGITUDE']] = df['geometry'].apply(extract_lat_lon)


    # Drop rows with missing essential values
    df = df.dropna(subset=['LATITUDE', 'LONGITUDE', 'DATE', 'TIME'])

    # Convert DATE and TIME
    df['DATE'] = pd.to_datetime(df['DATE'], errors='coerce')
    df['TIME'] = pd.to_datetime(df['TIME'], format='%H:%M:%S', errors='coerce').dt.time

    # Extract features
    df['YEAR'] = df['DATE'].dt.year
    df['MONTH'] = df['DATE'].dt.month
    df['DAY'] = df['DATE'].dt.day
    df['WEEKDAY'] = df['DATE'].dt.day_name()

    df['HOUR'] = df['TIME'].apply(lambda t: int(str(t).split(":")[0]) if pd.notnull(t) and ":" in str(t) else None)
    # Filter columns (can be adjusted based on needs)
    selected_columns = ['DATE', 'TIME', 'YEAR', 'MONTH', 'DAY', 'WEEKDAY', 'HOUR', 'LATITUDE', 'LONGITUDE', 'ACCLOC', 'IMPACTYPE', 'INJURIES', 'FATALITIES']
    df_filtered = df[[col for col in selected_columns if col in df.columns]]

    # Save cleaned data
    output_file = os.path.join(PROCESSED_DIR, "processed_data.csv")
    df_filtered.to_csv(output_file, index=False)
    print(f"✅ Cleaned data saved to {output_file}")

if __name__ == "__main__":
    latest_file = get_latest_raw_file()
    preprocess_data(latest_file)
