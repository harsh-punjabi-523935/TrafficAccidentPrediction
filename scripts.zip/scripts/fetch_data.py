import requests
import os
from datetime import datetime

# URL for the Toronto Open Data: Motor Vehicle Collisions dataset
CSV_URL = "https://ckan0.cf.opendata.inter.prod-toronto.ca/dataset/0b6d3a00-7de1-440b-b47c-7252fd13929f/resource/fdb2834f-3a92-41dd-b098-fbd84acb9cfe/download/Motor%20Vehicle%20Collisions%20with%20KSI%20Data%20-%204326.csv"

# Directory to save the file
SAVE_DIR = "../data/raw"
os.makedirs(SAVE_DIR, exist_ok=True)

# Filename with timestamp
today = datetime.now().strftime("%Y-%m-%d")
file_name = f"MVC_Collisions_{today}.csv"
file_path = os.path.join(SAVE_DIR, file_name)

def download_collision_data():
    print(f"Downloading data from {CSV_URL}...")
    response = requests.get(CSV_URL)
    
    if response.status_code == 200:
        with open(file_path, 'wb') as f:
            f.write(response.content)
        print(f"✅ Data saved to {file_path}")
    else:
        print(f"❌ Failed to download data. Status code: {response.status_code}")

if __name__ == "__main__":
    download_collision_data()
